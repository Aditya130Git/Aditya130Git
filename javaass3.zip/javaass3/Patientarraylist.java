import java.util.*;

class patient
{
	String pname;
	int pid;
	String diag;
	
	patient(String pname,int pid,String diag)
	{
		this.pname = pname;
		this.pid =  pid;
		this.diag = diag;
		
	}
	
	String getPname()
	{
		return pname;
	}
	int getPid()
	{
		return pid;
	}
	String getDiag()
	{
		return diag;
	}
	
	void padmmiitted() 
	{
		System.out.println("Enter number of days patient  admitted: ");
		
	}
	
}
class Patientarraylist
{
	ArrayList<patient> PT = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	
	void addpatient()
	{
		System.out.println("enter patient name: ");
		String newpatient = sc.nextLine();
	}
	
	void removepatient()
	{
		System.out.println("Enter patientname to remove: ");
		String nametoremove = sc.nextLine();
		
		for (int p=0; 1<PT.size(); p++)
		{
			if(p.getPname()==nametoremove)
			{
				PT.remove(nametoremove); 
				System.out.println("patient removed successfuly");
			}
		}
	}
	void specificdiad()
	{
		System.out.println("Enter patient diag: ");
		String specific = sc.nextLine();
		
		for(patient p:PT)
		{
			if (p.getDiag()==specific)
			{
				PT.display(p);
				System.out.println("patient with specific diag");
			}
		}
	} 
	void numberofdays()
	{
		int days = 10;
		System.out.println("enter number od days patient admitted: ");
		int admitfor = sc.nextInt();
		
		if(admitfor >= days)
		{
			System.out.println("patient admitted more than given days");
		}
	}
	
	void showMenu()
	{
		int choice;
		do
		{
			System.out.println("1.ADDPATIENT");
			System.out.println("2.REMOVEPATIENT");
			System.out.println("3.SPECIFICDIADPATIENT");
			System.out.println("4.NUMBROD=FDAYS");
			System.out.println("5.EXIT");
			System.out.println("enter your choice: ");
			
			choice = Integer.parseInt(sc.nextLine());
			
			switch(choice)
			{
			case 1:
				addpatient();
				break;
			case 2:
				removepatient();
				break;
			case 3:
				specificdiad();
				break;
			case 4:
				numbeofdays();
				break;
			case 5:
				System.out.println("exit");
			default :
				System.out.println("recheck");
			}
		}while(choice != 5 );
		
	}
	public static void main(String[] args)
	{
		Patientarraylist ptl = new Patientarraylist();
		ptl.showMenu();
	}	
	
}
