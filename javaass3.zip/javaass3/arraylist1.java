import java .util.*;

class Book
{
	String title;
	String author;
	String isbn;
	
	Book (String title, String author, String isbn)
	{
		this.title = title;
		this.author = author;
		this.isbn = isbn;
	}
	
	public String getTitle()
	{
		return title;
	}
	public String getAuthor()
	{
		return author;
	}
	public String getIsbn()
	{
		return isbn;
	}
	public void display()
	{
		System.out.printf("title: "+title, "auhtor: "+author, "isbn: "+isbn);
	}
}

class arraylist1
{
	ArrayList<Book> aa  = new ArrayList<>();
	Scanner sc =  new Scanner(System.in); 
	
	void addbook()
	{
		System.out.println("Book title: ");
		String title =  sc.nextLine();
		
		System.out.println("Book auhtor: ");
		String author =  sc.nextLine();
		
		
		System.out.println("Book isbn: ");
		String isbn =  sc.nextLine();
	}
	
	void removebook()
	{
		System.out.println("Enter isbn: ");
		String isbn = sc.nextLine();
		
		for(Book book : aa)
		{
			if(book.getIsbn().equals( isbn))
			{
				aa.remove(book);
				System.out.println("Book removed ");
				return; 
			}
		}
		System.out.println("book removed with this isbn");
	}
	
	void searchbook()
	{
		System.out.println("enter title of book to serch: ");
		String title = sc.nextLine();
		
		for(Book book : aa)
		{
			if(book.getTitle().equalsIgnoreCase(title)) 
			{
				System.out.println("book found");
				book.display();
			}
		}
		System.out.println("book not found with this title");
	}
	
	void DisplayAllbook() 
	{
		if(aa.isEmpty())
		{
			System.out.println("no books: ");
			return;
		}
		
		System.out.println("book in the library: ");
		for(Book book : aa)
		{
			book.display();
		}
		System.out.println();
	}
	
void showMenu()
{
	int choice;
	do
	{
		 System.out.println("------Library Management------");
		 System.out.println("1.ADD BOOK: ");
		 System.out.println("2.REMOVE BOOK: ");
		 System.out.println("3.SEARCH BOOK :");
		 System.out.println("4.DISPLAY ALL BOOK: ");
		 System.out.println("5.EXIT: ");
		 System.out.println("Enter your choice: ");
		 
		 choice = Integer.parseInt(sc.nextLine());
		 
		 switch(choice)
		 {
		 case 1:
			 addbook();
			 break;
		 case 2:
			 removebook();
			 break;
		 case 3:
			 searchbook();
			 break;
		 case 4:
			 DisplayAllbook();
			 break;
		 case 5:
			 System.out.println("exiting");
			 break;
		 default :
			 System.out.println("invalid choice");
		 }
	}while(choice != 5);
}

public static void main(String[] args)
{
	arraylist1 al = new arraylist1();
	al.showMenu();
}

	
	
	
	
	
	
}