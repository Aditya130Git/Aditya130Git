class Vehicle
{
	String make;
	String model;
	String year;
	
	Vehicle(String make, String model, String year)
	{
		this.make=make;
		this.model=model;
		this.year=year;
		
	}
	 
	public String  getModel()
	{
		
		return model;
	}
	
	public void setModel(String newModel)
	{
		this.model=newModel;
		System.out.println("new model name updated: " + this.model);
	}
	
}
	class Car extends Vehicle
	{
		String numbersofdoors; 
		
		Car(String make, String model,String year)
		{
			super(make,model,year);
		}
		
		Car(String make, String model, String year, String numbersofdoors)
		{
			super(make,model,year);
			this.numbersofdoors=numbersofdoors;
			
		}		
		
	}
public class Oops
{
	public static void main(String[] args)
	{
		Vehicle v = new Vehicle("mahindra","thar","2024");
		System.out.println("initial brand: " + v.getModel());
		v.setModel("TATA");
		System.out.println("edited brand: " + v.getModel());
		
	}
}