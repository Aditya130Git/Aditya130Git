import java.util.*;

class Emp
{
	String name;
	int id;
	String deptname;
	
	Emp(String name, int id, String deptname)
	{
		this.name = name;
		this.id = id;
		this.deptname = deptname;
	}
	
	String getName() 
	{
		return name;
	}
	int getId() 
	{
		return id;
	}
	String getDeptname() 
	{
		return deptname;
	}
	void setDeptname(String newDeptname)
	{
		this.deptname  = newDeptname;
	}
	
	void display()
	{
		System.out.printf(name , id , deptname);
	}
}
class aaralist2
{
	ArrayList<Emp> AE = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	
	void addEmp()
	{
		System.out.println("Enter new employee name: ");
		String name = sc.nextLine();
		
		System.out.println("Enter new employee id: ");
		String id = sc.nextLine();
		
		System.out.println("Enter new employee dept: ");
		String dept = sc.nextLine();
	}
	void updateDept()
	{
		System.out.println("enter empid: ");
	    int empid = Integer.parseInt(sc.nextLine());
		for(Emp e:AE)
		{
			if(e.getId()==empid)
			{ 
				System.out.println("enter newly department: ");
				String newdept=sc.nextLine();
				e.setDeptname(newdept);
				System.out.println("employee add sucessflly ");
				return;	
			}
		}
		System.out.println("emp id  not  foumd try again");
		
	}
	
	void removeEmp()
	{
		System.out.println("enter id to be removed: ");
		int emptodel = sc.nextInt();
		sc.nextLine();
		
		for (Emp  e:AE)
		{
			if(e.getId()==emptodel)
			{
				AE.remove(e);
				System.out.println("employee removed successfully");
				return;
			}
		}
	}
	void display()
	{
		if(AE.isEmpty())
		{
			System.out.println("its empty");
		}
		for(Emp e:AE)
		{
			e.display();
		}
		System.out.println();
	}
	
	void showMenu()
	{
		int choice;
		do
		{
			System.out.println("-----Employee management-----");
			System.out.println("1.ADD EMPLOYEE");
			System.out.println("2.UPDATE DEPT BY EMPID");
			System.out.println("3.REMOVE EMP BY EMPID");
			System.out.println("4.DISPLAY");
			System.out.println("5.EXIT");
			System.out.println("enter your choice: ");
			
			choice = Integer.parseInt(sc.nextLine());
			switch(choice)
			{
			case 1:
				addEmp();
				break;
			case 2:
				updateDept();
				break;
			case 3:
				removeEmp();
				break;
			case 4:
				display();
				break;
			case 5:
				System.out.println("Exit");
			default :
				System.out.println("invalid");
				
			}

			
		}while(choice!=5);
	}
}
class EmployeeManagement
{
	public static void main(String[] args)
	{
		Emp al = new Emp();
		al.showMenu();
	} 
}
















		