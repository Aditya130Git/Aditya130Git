class Employee
{
	String ename;
	int empid;
	String dept;
	
	Employee(String ename, int empid, String dept)
	{
		this.ename = ename;
		this.empid = empid;
		this.dept = dept;
		
	}
	
	public String getEname()
	{
		return ename;
	}
	
	public int getEmpid()
	{
		return empid;
	}
	
	public String getDept()
	{
		return dept;
	}
	
	public void setEname(String newEname)
	{
		this.ename = newEname;
		System.out.println("updates your initial name: " + this.ename);
	}
	
	public void setEmpid(int newEmpid)
	{
		this.empid = newEmpid;
		System.out.println("updates your initial name: " + this.empid);
	}
	
	public void setDept(String newDept)
	{
		this.dept = newDept;
		System.out.println("updates your initial name: " + this.dept);
	}
	
}
class Manager extends Employee
{
	int  teammanaged;
	
	Manager(String ename, int empid, String dept, int teammanaged)
	{
		super(ename , empid, dept);
		this.teammanaged = teammanaged;
	}
	
	Manager(String ename,  int  empid)
	{
		super(ename,empid,"default"); 
	}
}

public class employeeQB
{
	public static void main(String[] args) 
	{
		Employee e = new Employee("Aditya",120,"IT");
		System.out.println("details: " + e.getEname());
		System.out.println("details: " + e.getEmpid());
		System.out.println("details: " + e.getDept());
		 e.setEname("Shivam");
		 e.setEmpid(231);
		 e.setDept("marketing");
		 
		 System.out.println("Updated details: " +e.getEname());
		 System.out.println("Updated details: " +e.getEmpid());
		 System.out.println("Updated details: " +e.getDept());

		 		
	}
}