class Person
{
	String pname;
	int age;
	
	Person(String pname, int age)
	{
		this.pname = pname ;
		this.age = age;
	} 
	
	public String getPname()
	{
		return pname;
	}
	
	public int getAge()
	{
		return age;
	}
	
	public String setPname(String newPname)
	{
		this.pname = newPname;
		return pname;
	}
	
	public int setAge(int newAge)
	{
		this.age = newAge;
		return age;
	} 
}
class Student extends Person
{
	String grade;
	
	Student(String pname,int age,String grade)
	{
		super(pname,age);
		this.grade = grade;
	}
	
	Student(String pname ,int age)
	{
		super(pname,age);
	}
}

public class EducationQB
{
	public static void main(String[] args)
	{
		Person p = new Person("aditya",21);
		System.out.println("initial details; " +p.getPname());
		System.out.println("Initial details: " +p.getAge());
		
		p.setPname("alisha");
		p.setAge(22);
		
		System.out.println("updated details: " +p.getPname());
		System.out.println("Updated details; " +p.getAge());
	}	
	
}

	

