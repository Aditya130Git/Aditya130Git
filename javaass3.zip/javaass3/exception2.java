import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class exception2 {

    
    private static final int MAX_TICKETS = 10;
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        
        try {
            System.out.print("Please enter the number of tickets you want to book (e.g., 2): ");
            int numberOfTickets = sc.nextInt();
            
            sc.nextLine();  
            
            bookTickets(numberOfTickets);
            
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. You must enter a whole number for the number of tickets.");
            sc.nextLine();
        } catch (IllegalArgumentException e) {
            System.out.println("Booking Error: " + e.getMessage());
        }
                
                
        System.out.println("--- Handling IndexOutOfBoundsException ---");
        List<String> availableSeats = new ArrayList<>();
        availableSeats.add("A1");
        availableSeats.add("A2");
        availableSeats.add("A3");
        
        System.out.println("Available seats: " + availableSeats);
        System.out.println("Seat indices are from 0 to " + (availableSeats.size() - 1));
        
        try {
            System.out.print("Please enter the index of the seat you want to select (e.g., 0 for seat A1): ");
            int seatIndex = sc.nextInt();
            String selectedSeat = availableSeats.get(seatIndex);
            
            System.out.println("You have successfully selected seat: " + selectedSeat);
            
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter a valid number for the seat index.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Error: The seat index you entered is not available.");
            System.out.println("Please choose a seat from the available list.");
        } finally {
            System.out.println("\n--- End of program. Cleaning up resources. ---");
            sc.close();
        }
    }
    
   
    public static void bookTickets(int count) {
       
        if (count <= 0) {
            throw new IllegalArgumentException("You must book at least one ticket.");
        }
        
        if (count > MAX_TICKETS) {
            throw new IllegalArgumentException("You can only book a maximum of " + MAX_TICKETS + " tickets at a time.");
        }
        
        System.out.println("Success! Booking " + count + " ticket(s).");
    }
}
