import java.util.*;

class Ticket
{
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		String[] seats = {"A1","A2","A3"};
		
		try 
		{
			System.out.println("enter no of tickets: ");
			int tickets = sc.nextInt();
			
			if(tickets <=0)
			{
				throw new IllegalArgumentException("number of tickets must be gretaer than zero");
				
			}
			System.out.println("enter seats on index");
			int seatIndex = sc.nextInt();
			
			System.out.println(seats[seatIndex]);
		}
		catch(InputMismatchException e)
		{
		 System.out.println("enter the valid input");
		}
		catch(IllegalArgumentException e)
		{
			System.out.println("error");
		}
		catch(IndexOutofBoundsException e) 
		{
			System.out.println("error");
		}
		System.out.println("booking finished");
	}
}

