class ABC 
{
	int stuid;
	String name;
	String grade;
	
	ABC(int stuid, String name, String grade)
	{
		this.stuid = stuid;
		this.name = name;
		this.grade = grade;
	}
	
	public String getGrade()
	{
		return grade; 
	}
	
	public String setGrade(String newGrade)
	{
		this.grade = newGrade;
		return grade;
	}
	
	public void display()
	{
		System.out.println("Student details: " +stuid +name +grade);
	}
}

public class StudentQB
{
	public static void main(String[] args)
	{
		ABC s = new ABC(1," Alisha"," A");
		System.out.println("initial details: " + s.getGrade());
		s.display();
		
		s.setGrade("B");
		System.out.println("udgarded grade: " +s.getGrade());
		
		
		
		
		
				
	}
}