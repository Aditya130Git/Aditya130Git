import java.util.*;

public class parseintexception
{
	public static void main(String[] args)
	{
		String accnum;
		Scanner  sc  =  new Scanner(System.in);
		System.out.println("enter your account number: ");
		accnum = sc.nextLine();
		int number = 0;
		
		
		try 
		{
			number = Integer.parseInt(accnum);
			
		}
		
		catch(NumberFormatException ne)
		{
			System.out.println("cant convert");
		}
		
		catch(NullPointerException npe)
		{
			System.out.println("String can not  be null");
		}
		
		finally
		{
			System.out.println("conersion attempt complete: ");
		}
		sc.close();
	}
}



